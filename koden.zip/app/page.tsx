import MetallicButton from "./components/MetallicButton";
import ThemeToggle from "./components/ThemeToggle";
export default function Home(){return(<main className='p-10'><h1>koden – Create Apps Instantly</h1><ThemeToggle/><MetallicButton label='Generate App'/></main>);}