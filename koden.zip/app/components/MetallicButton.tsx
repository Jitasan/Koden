"use client";
export default function MetallicButton({label}){
 return(<button style={{
  padding:"15px 30px",
  borderRadius:"12px",
  backgroundImage:"var(--metallic)",
  backgroundSize:"cover",
  border:"none",
  boxShadow:"0 4px 10px rgba(0,0,0,0.3)",
  fontSize:"1.1rem",
  cursor:"pointer",
  color:"white"
 }}>{label}</button>);
}