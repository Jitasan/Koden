import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    ok: true,
    service: "Koden API",
    message: "Backend is running!",
    timestamp: new Date().toISOString(),
  });
}
