import { NextRequest, NextResponse } from "next/server";

// In-memory project store
let projects: { id: string; name: string; targets: string[] }[] = [];

function createId() {
  return Math.random().toString(36).slice(2, 10);
}

export async function GET() {
  return NextResponse.json(projects);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = (body.name ?? "").trim();
    const targets: string[] = Array.isArray(body.targets)
      ? body.targets
      : ["web"];

    if (!name) {
      return NextResponse.json({ error: "Name is required" }, { status: 400 });
    }

    const project = { id: createId(), name, targets };
    projects.push(project);
    return NextResponse.json(project, { status: 201 });
  } catch (err) {
    return NextResponse.json({ error: "Failed to create project" }, { status: 500 });
  }
}
