import { Router } from "express";
const router=Router();
router.post("/",(req,res)=>{
 const {projectType}=req.body;
 res.json({success:true,message:`Generated ${projectType} project.`});
});
export default router;