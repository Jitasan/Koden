# koden Resources

This archive contains additional resources for koden:

- `deployment/` — deployment guides and Wix DNS instructions.
- `mobile/` — React Native (Expo) template and Capacitor notes.
- `ai/` — AI integration stubs and server hooks.
- `builder/` — drag-and-drop builder starter components (React + react-dnd).
- `templates/` — extra app templates (dashboard, ecommerce).
- `ci/` — GitHub Actions workflows for frontend and backend.
- `generator/Dockerfile` — Dockerfile for the generator service.

Use these to extend the koden monorepo.
